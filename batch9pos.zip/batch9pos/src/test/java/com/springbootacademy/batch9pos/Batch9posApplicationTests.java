package com.springbootacademy.batch9pos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch9posApplicationTests {

	@Test
	void contextLoads() {
	}

}
