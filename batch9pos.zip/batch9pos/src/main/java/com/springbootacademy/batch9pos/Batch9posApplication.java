package com.springbootacademy.batch9pos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch9posApplication {

	public static void main(String[] args) {
		SpringApplication.run(Batch9posApplication.class, args);
	}

}
